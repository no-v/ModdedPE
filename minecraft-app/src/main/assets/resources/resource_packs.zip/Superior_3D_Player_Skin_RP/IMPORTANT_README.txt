If you are going to publish this pack on a website, a pack, or post it on youtube. Make sure sure you credit me otherwise; I will take action. This pack will be sent to some bedrock content creators first and then the Bedrock SMP Discord Servers I’m in. For the quick release, you can join these discord servers which I’ll be posting this pack on first before mcpedl.

Bedrock Add-Ons | dev-resources || https://discord.gg/QtdQaYf6

Assassins SMP Public | promote || https://discord.gg/Zfm36Ga5

DoveCraft Community Server | self-promo || https://discord.gg/mG3574UT

Loyalty SMP Public Discord | your-creations || https://discord.gg/BX3hU5TD

CHALLY’S VILLAGE | self-promote || https://discord.gg/ZZjwaQeE

Barebones SMP Community | self-promo || https://discord.gg/RAqdbfEY

Gumball SMP Public | self_promo || https://discord.gg/SBRmrmG3

Obscure Public | media || https://discord.gg/U9eHFbaD

Nebulum Public | promo || https://discord.gg/AXV4ywRB

----------------------------------------------------------------------------------

Please consider going to check out these people for making this pack be possible.

original 3D Player Skin in mcpedl made by: Vblack867
mcpedl: https://mcpedl.com/user/vblack867/
youtube: https://www.youtube.com/channel/UC6uEe0Ksy1-zvUaOkYAVBhQ

----------------------------------------------------------------------------------

I'm going to be making more packs soon, so consider subscribing to my Youtube channel to get updates:
https://www.youtube.com/channel/UCj7J71iHWtfgzKDdbXbS8ag