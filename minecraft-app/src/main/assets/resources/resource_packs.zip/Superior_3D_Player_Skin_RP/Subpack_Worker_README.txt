Subpack Worker: Hello there. You’re here because you wanted to see how the pack works, right?

Subpack Worker: If not that’s fine. You can explore the pack. I’m sure you’re not going to find anything interesting.

Subpack Worker: Let me know.


